%% CS-1 dissipative sheet - ESD analysis
%
% Run sections individually (Ctrl+Enter) or the whole file.
% Outputs go to results/.
%
% Successor to Generate1.m: same network and geometry, solved directly as a
% sparse system rather than one LTspice run per node.

clear; close all; clc;
outDir = 'results';
if ~exist(outDir,'dir'), mkdir(outDir); end


%% DC resistance sweep - six cases, one figure each
% Replaces Generate1.m and plot_result.m.

sweepR = [10e6 25e6 50e6];
sweepS = { [500 500],          '2straps'
           [200 200; 740 740], '4straps' };

fprintf('%-24s %8s %12s %12s %9s\n','case','nodes','Rmin(MOhm)','Rmax(MOhm)','spread');
for ri = 1:numel(sweepR)
    for si = 1:size(sweepS,1)
        p = esd_config('rStrapEach', sweepR(ri), 'strapPosMM', sweepS{si,1});
        tag = sprintf('results_%gMOhm_%s', sweepR(ri)/1e6, sweepS{si,2});
        [AreaPlot, info] = esd_solve(p);

        fprintf('%-24s %8u %12.4f %12.4f %8.3f%%\n', tag, info.nNodes, ...
                info.minR/1e6, info.maxR/1e6, info.spreadPct);
        save(fullfile(outDir,[tag '.mat']), 'AreaPlot','p','info');

        fig = figure('Name', tag, 'Position', [60 60 900 460]);
        esd_plot(AreaPlot/1e6, p, info);
        colormap(turbo);  cb = colorbar;
        cb.Label.String = 'R to structure  (M\Omega)';
        title([strrep(tag,'_','  ') ...
               sprintf('   %.4f to %.4f M', info.minR/1e6, info.maxR/1e6) ...
               '\Omega' sprintf('  (spread %.3f%%)', info.spreadPct)]);
        exportgraphics(fig, fullfile(outDir,[tag '.png']), 'Resolution', 200);
    end
end


%% Charging - where the panel actually charges up
% Only interesting with the substrate active.  The thread-only network puts
% every node on a thread, so the answer is a uniform few tens of volts.

J    = 10e-6;      % A/m^2, severe substorm
rhoS = 1e13;       % ohm/sq

p = esd_config('substrateRes', rhoS, 'gap', 7);
[Vmap, ic] = esd_solve(p, 'charge', J);
fprintf('\nCharging at %g uA/m^2, rho_s = %.3g:\n', J*1e6, rhoS);
fprintf('  threads %.4g V, between threads %.4g V (%.0fx)\n', ...
        ic.maxThreadV, ic.maxSubstrateV, ic.maxSubstrateV/ic.maxThreadV);

f = figure('Position',[60 60 1300 560]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile; esd_plot(Vmap/1000, p, ic);
colormap(turbo); cb = colorbar; cb.Label.String = 'potential (kV)';
title(sprintf('Whole panel, peak %.3g kV', ic.maxV/1000));

nexttile;                                   % a few cells, so the structure shows
step = p.gap + 1;  sel = 1:(6*step+1);
xx = (sel-1)/step * p.threadSep;
imagesc(xx, xx, Vmap(sel,sel).'/1000);
set(gca,'YDir','normal'); axis image;
colormap(turbo); cb = colorbar; cb.Label.String = 'potential (kV)';
xlabel('W (mm)'); ylabel('L (mm)'); title('Six cells');
exportgraphics(f, fullfile(outDir,'charging_map.png'), 'Resolution', 200);

% Peak goes as pitch^2, so pitch is the lever - not strap resistance.
pitch = [10 15 20 30 40 60];
Vp = zeros(size(pitch));
for k = 1:numel(pitch)
    [~, iq] = esd_solve(esd_config('substrateRes',rhoS,'threadSep',pitch(k)), 'charge', J);
    Vp(k) = iq.maxSubstrateV;
end
f = figure('Position',[80 80 620 460]);
loglog(pitch, Vp, 'o-', 'LineWidth',1.6); grid on; hold on;
loglog(pitch, Vp(pitch==30)*(pitch/30).^2, 'k--');
yline(11000,'r--','11 kV');
xlabel('thread pitch (mm)'); ylabel('peak cell potential (V)');
legend('model','a^2','Location','northwest');
title('Differential charging vs thread pitch');
exportgraphics(f, fullfile(outDir,'charging_levers.png'), 'Resolution', 200);


%% Impedance vs frequency
% At f = 0 the reactive terms vanish exactly, so the DC maps above contain
% none of this.

freqs = logspace(0, 9, 61);
caps  = [0.1e-9 1e-9 10e-9];
p0    = esd_config();
probe = [1 1];                              % corner

Z = zeros(numel(freqs), numel(caps));
for ci = 1:numel(caps)
    p   = esd_config('panelCap', caps(ci));
    net = esd_network(p);
    col = net.gridRow(probe(1), probe(2));
    for fi = 1:numel(freqs)
        [Y, isReal] = esd_network(net, freqs(fi));
        if isReal, dY = decomposition(Y,'chol'); else, dY = decomposition(Y,'lu'); end
        e = zeros(net.n,1);  e(col) = 1;
        x = dY \ e;
        Z(fi,ci) = x(col);
    end
end

Rdc = p0.nbLen*p0.rStrapEach/p0.nbWid / nnz(p0.strapPosMM);
f = figure('Position',[60 60 1000 640]);
tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
nexttile; semilogx(freqs, 20*log10(abs(Z)), 'LineWidth',1.4); grid on;
ylabel('|Z| (dB\Omega)'); yline(20*log10(Rdc),'k:','strap floor');
legend(arrayfun(@(c) sprintf('%g nF', c*1e9), caps, 'UniformOutput',false), ...
       'Location','southwest');
nexttile; semilogx(freqs, angle(Z)*180/pi, 'LineWidth',1.4); grid on;
ylabel('phase (deg)'); xlabel('frequency (Hz)'); ylim([-95 15]);
exportgraphics(f, fullfile(outDir,'impedance_vs_frequency.png'), 'Resolution', 200);

fprintf('\nRC corner against the %.3g ohm strap floor:\n', Rdc);
for c = caps, fprintf('  %5.3g nF -> %.3g Hz\n', c*1e9, 1/(2*pi*Rdc*c)); end
fprintf('Sheet L only rivals segment R at %.3g Hz\n', p0.segRes/(2*pi*p0.segInd));


%% Transient - pre-charged panel discharging through an arc
% Fills in the peak-power block Generate1.m left empty at line 281.

V0       = 11000;      % V, the "x kV"
standoff = 5e-3;       % m, sheet to structure
area     = (p0.sheetW/1000)*(p0.sheetL/1000);
C        = 8.854e-12 * area / standoff;      % the "y nF"

fprintf('\n%.3g m^2 at %g mm standoff -> C = %.3g nF, %.4g mJ at %g V\n', ...
        area, standoff*1e3, C*1e9, 0.5*C*V0^2*1e3, V0);

out = esd_transient(esd_config('panelCap',C), struct('V0',V0));

f = figure('Position',[60 60 1100 720]);
tiledlayout(2,1,'TileSpacing','compact','Padding','compact');
nexttile; semilogx(out.t, out.iArc, 'LineWidth',1.5); grid on;
ylabel('arc current (A)');
title(sprintf('Peak %.3g A, %.4g mJ stored', out.peakArcI, out.energyInit*1e3));
nexttile; semilogx(out.t, out.Vprobe/1000, 'LineWidth',1.4); grid on;
ylabel('node potential (kV)'); xlabel('time (s)');
legend(out.probeNames, 'Location','southwest');
exportgraphics(f, fullfile(outDir,'transient_waveforms.png'), 'Resolution', 200);

f = figure('Position',[80 80 1400 480]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile; esd_plot(log10(out.PeakPowerMap), out.p, out);
colormap(turbo); cb = colorbar; cb.Label.String = 'log_{10} peak power (W)';
title('Peak power per element');
nexttile; esd_plot(log10(out.EnergyMap*1e3), out.p, out);
colormap(turbo); cb = colorbar; cb.Label.String = 'log_{10} energy (mJ)';
title(sprintf('Energy per element (%.3g mJ total)', ...
      sum(out.EnergyMap(:),'omitnan')*1e3));
exportgraphics(f, fullfile(outDir,'transient_peak_maps.png'), 'Resolution', 200);

fprintf('Charge balance %.2f%% of C*V0\n', 100*out.chargeArc/(C*V0));


%% Survival and margins
% Thread properties are inferred from the quoted 12500 ohm/m and assumed
% carbon values.  Replace them before quoting any of this.

rhoE = 1.5e-5;   % ohm m, thread resistivity
rhoM = 1800;     % kg/m^3
cp   = 700;      % J/(kg K)
Tmax = 3600;     % K

A_th = rhoE / p0.linRes;
dT   = out.energyBranch / (rhoM * A_th * p0.segLen * cp);

fprintf('\nThread %.3g um diameter implied by %g ohm/m\n', ...
        2*sqrt(A_th/pi)*1e6, p0.linRes);
fprintf('Worst segment %.4g mJ -> %.4g K rise, %.1fx margin to %g K\n', ...
        max(out.energyBranch)*1e3, max(dT), Tmax/max(dT), Tmax);
fprintf('Field at %g V across %g mm: %.3g MV/m ', V0, standoff*1e3, V0/standoff/1e6);
fprintf('(air ~3, surface flashover ~1-10, bulk polyimide ~150-300)\n');

fprintf('\nBleed time constants and equilibrium potential at 10 uA/m^2:\n');
for ri = 1:numel(sweepR)
    p = esd_config('rStrapEach', sweepR(ri));
    [~, id] = esd_solve(p);
    fprintf('  %2g MOhm: tau = %.3g s, V_eq = %.3g V\n', sweepR(ri)/1e6, ...
            id.maxR*C, 10e-6*area*id.maxR);
end
