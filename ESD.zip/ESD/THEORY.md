# Theory and algorithms behind the ESD sheet model

Everything the code relies on, with the named results stated properly and a
pointer to where each one appears in the source.

---

## 1. Physics → circuit

### 1.1 Kirchhoff's Current Law

Charge is conserved, so in steady state the current into any node equals the
current out. With `i_k` the current injected from outside:

```
Σ_j  g_kj (V_k − V_j)  =  i_k
```

where `g_kj = 1/R_kj`. This is just `∇·J = 0` applied to a lumped network.

### 1.2 Nodal analysis

Rearranging the sum above:

```
V_k · (Σ_j g_kj)  −  Σ_j g_kj V_j  =  i_k
```

which is one row of `G·v = i` with

- `G(k,k)` = sum of every conductance touching node k
- `G(k,j)` = −g_kj

Ground carries no equation, because `V₀ = 0` is known rather than solved for.
A resistor from *k* to ground therefore adds `g` to `G(k,k)` and contributes
no off-diagonal entry — the `g·V₀` term vanishes.

Only resistors and current sources appear here, so plain nodal analysis
suffices. Modified Nodal Analysis (MNA) would only be needed for voltage
sources or current-controlled elements.

**In the code:** `conductance()` in `ESD_Model.m`, `esd_admittance.m`.

---

## 2. G is a grounded graph Laplacian

For a weighted graph, the **Laplacian** is `L = D − A` (weighted degree minus
adjacency). It is singular: every row sums to zero, so `L·1 = 0`.

Our `G` is `L` with the ground node's row and column deleted — the
**grounded** (or Dirichlet) Laplacian. Deleting that row and column is a
principal submatrix operation, and it is exactly what makes the system
solvable.

### Theorem (grounded Laplacian is SPD)

*Let L be the Laplacian of a weighted graph with positive edge weights on
nodes {0, 1, …, n}, and let G be L with row and column 0 removed. If every
node has a path to node 0, then G is symmetric positive definite.*

**Proof.** Symmetry is immediate from `G(k,j) = G(j,k) = −g_kj`.

For definiteness, take any `x ∈ ℝⁿ` and extend it to `x̃` on all n+1 nodes by
setting `x̃₀ = 0`. Then

```
xᵀGx  =  x̃ᵀLx̃  =  Σ_edges  g_kj (x̃_k − x̃_j)²   ≥ 0
```

A sum of squares with positive weights. It equals zero only if `x̃_k = x̃_j`
across every edge, i.e. `x̃` is constant on each connected component. Since
every component contains node 0 and `x̃₀ = 0`, that forces `x̃ ≡ 0`, hence
`x = 0`. ∎

**The physical reading:** `xᵀGx` is the power the network dissipates when the
node voltages are `x`. Positive definiteness is the statement that *a resistor
network always burns power unless nothing is happening.*

### Why this matters operationally

The connectivity hypothesis is not decorative. A node carrying no resistor at
all gives a zero row, `G` becomes singular, and the factorisation fails. The
sheet has 137 × 53 = 7,261 grid positions but only **3,283** carry a thread,
so the rest must be removed before assembly.

**In the code:** the `live = dg > 0` mask in `buildNetwork()`.

---

## 3. The key identity: resistance is a diagonal entry of the inverse

Solve `v = G⁻¹ i`. Inject 1 A at node *k* alone, so `i = e_k`. Then
`v = G⁻¹e_k`, the k-th **column** of `G⁻¹`, and the voltage at node *k* is
the k-th entry of that column:

```
R_k = (G⁻¹)_kk
```

Since `I = 1 A`, the measured voltage *is* the resistance. Last year's code
did this physically — 1 A source, read `V` — without exploiting that the
matrix never changes.

### Connection: effective resistance / resistance distance

`R_k` is the **effective resistance** between node *k* and ground. In graph
theory this is the *resistance distance* of Klein & Randić (1993). Generally,
between any two nodes,

```
R_eff(i,j) = (e_i − e_j)ᵀ L⁺ (e_i − e_j)
```

with `L⁺` the Moore–Penrose pseudoinverse. Grounding one node reduces this to
the diagonal of `G⁻¹`.

### Reciprocity

`G` symmetric ⟹ `G⁻¹` symmetric ⟹ `(G⁻¹)_jk = (G⁻¹)_kj`. Physically this is
the **reciprocity theorem**: injecting 1 A at *j* and measuring at *k* gives
the same reading as injecting at *k* and measuring at *j*. It is what permits
Cholesky, and it is a real statement about the circuit, not a convenience.

**In the code:** the `sub2ind` line in `solveMap()` picks `X(col_k, k)`.

---

## 4. Cholesky decomposition

### Theorem (existence and uniqueness)

*Every symmetric positive definite A admits a unique factorisation
`A = LLᵀ` with L lower triangular and strictly positive diagonal.*

The algorithm, column by column:

```
L(j,j) = sqrt( A(j,j) − Σ_{k<j} L(j,k)² )
L(i,j) = ( A(i,j) − Σ_{k<j} L(i,k)L(j,k) ) / L(j,j)      for i > j
```

Positive definiteness guarantees the square root is always of a positive
number, so the algorithm never breaks down.

### Why Cholesky rather than LU

Cholesky on an SPD matrix is **backward stable without pivoting**. The element
growth factor is bounded by 1, so no row interchanges are needed. LU on a
general matrix requires partial pivoting for stability, which costs both time
and sparsity. Cholesky also does half the work of LU (`n³/3` versus `2n³/3`
flops dense) and stores half the factor.

**In the code:** `decomposition(G, 'chol')`.

---

## 5. Sparse factorisation, fill-in and ordering

Sparse Cholesky creates nonzeros in `L` where `G` had none. This is
**fill-in**, and how much you get depends entirely on the order the nodes are
eliminated in. Choosing the order that minimises fill is **NP-hard**, so
practical codes use heuristics:

- **AMD** — approximate minimum degree
- **Nested dissection** — recursively split the graph by a small separator,
  order the two halves first and the separator last

### Theorem (George, 1973)

*For a √N × √N two-dimensional grid graph, nested dissection produces
`O(N log N)` fill and requires `O(N^1.5)` factorisation flops.* This is
optimal up to constant factors for 2-D meshes.

Our matrix is 3,297 × 3,297 on a mesh, so `N^1.5 ≈ 1.9 × 10⁵` flops —
microseconds of actual arithmetic. MATLAB's sparse `chol` calls CHOLMOD
(Tim Davis), which selects an ordering automatically.

---

## 6. Solving 3,283 right-hand sides

With `G = LLᵀ` in hand, each solve is two triangular sweeps:

```
forward:   L y = b        O(nnz(L))
backward:  Lᵀ x = y       O(nnz(L))
```

The factorisation is paid **once**; every subsequent right-hand side is cheap.
That is the entire speedup:

| | factorisations | solves |
|---|---|---|
| `Generate1.m` | 3,283 per case | 3,283 |
| this model | **1** per case | 3,283 |

### Blocking

The code solves 512 right-hand sides at a time rather than one:

```matlab
E      = full(sparse(cols, 1:nc, 1, n, nc));
X      = dG \ E;
R(s:e) = X(sub2ind([n nc], cols(:), (1:nc)'));
```

`E` is 512 unit vectors side by side. This turns the back-substitutions from
matrix–vector operations (BLAS-2) into matrix–matrix ones (BLAS-3), which get
far better cache reuse. The block size trades memory (`n × 512` doubles ≈
13 MB) against that efficiency.

### Why not just form G⁻¹?

1. **The inverse of a sparse matrix is generally dense.** 3,297² entries ≈
   87 MB, against ~30 k nonzeros in the factor.
2. **Explicit inversion is numerically worse** than solving. The standard
   advice — never invert to solve — applies.
3. **Only the diagonal is wanted.** Computing all 10.8 M entries to keep 3,283
   is waste.

A sharper algorithm exists for exactly this: **selected inversion** (Takahashi's
equations, or SelInv), which extracts `diag(A⁻¹)` in the same asymptotic cost
as the factorisation itself. It would be the right tool at much larger scale;
at 3,283 nodes the blocked solve already runs in 0.4 s.

---

## 7. The AC extension

### Phasor analysis

For steady-state sinusoidal excitation, substitute `d/dt → jω`. Element laws
become algebraic:

| element | impedance | admittance |
|---|---|---|
| R | `R` | `1/R` |
| L | `jωL` | `1/(jωL)` |
| C | `1/(jωC)` | `jωC` |

R and L in series give one branch of admittance `1/(R + jωL)`; a capacitor to
structure contributes `jωC` on the diagonal. Assembly is otherwise identical.

At `ω = 0`: `1/(R + j·0·L) = 1/R` and `j·0·C = 0`. The AC matrix collapses
**exactly** onto `G` — not approximately. This is why the DC results are
bit-identical whether or not the reactive terms are present.

### Complex symmetric ≠ Hermitian

`Y = Yᵀ` (symmetric) but `Y ≠ Ȳᵀ` (not Hermitian). Cholesky requires
Hermitian positive definite, so it does not apply — a complex symmetric matrix
has no `LLᵀ` factorisation in general. The code falls back to LU with partial
pivoting (UMFPACK).

**In the code:** `esd_admittance.m`, and the `isReal` branch in
`esd_solve_map.m`.

---

## 8. The continuum problem between threads

The circuit model has nodes only on threads. The insulating substrate between
them needs a PDE.

### Derivation

Surface Ohm's law, with `σs = 1/ρs` the surface conductivity and `J_s` the
current per unit *width*:

```
J_s = −σs ∇V
```

Charge arrives from the environment at `J` amps per unit **area**. In steady
state what arrives must flow away:

```
∇·J_s = J    ⟹    −σs ∇²V = J    ⟹    ∇²V = −J·ρs
```

Poisson's equation with a uniform source, with `V = 0` on the cell boundary
(the threads, which sit at ~19 V — negligible beside kilovolts).

### Nondimensionalisation

Write `x = a·ξ` with `a` the cell side, so `∇²_x = (1/a²)∇²_ξ`:

```
∇²_ξ V = −J·ρs·a²
```

Substituting `V = J·ρs·a²·u` removes every physical quantity:

```
∇²_ξ u = −1,    u = 0 on ∂(unit square)
```

All the physics is now in the prefactor, and `max u` is a **universal
constant**.

### Solving it two ways

**Fourier series.** Expand the constant source in a double sine series:

```
1 = Σ_{m,n odd}  16/(π² mn) · sin(mπx) sin(nπy)
```

Each mode of the Laplacian scales by `−(m²+n²)π²`, so

```
u(x,y) = Σ_{m,n odd}  16/(π⁴ · mn · (m²+n²)) · sin(mπx) sin(nπy)
```

The leading term at the centre is `16/(2π⁴) = 0.0821`; the alternating tail
brings it down.

**Finite difference.** The 5-point stencil on a grid is a Kronecker sum:

```
A = I ⊗ T + T ⊗ I,     T = tridiag(1, −2, 1)/h²
```

A 201 × 201 grid gives **0.07367**, agreeing with the series.

### Result

```
V_max = 0.0737 · J · ρs · a²
```

The **a²** is the design content: differential charging between threads scales
with the *square* of thread pitch. Strap resistance appears nowhere.

---

## 9. Supporting results

### Sheet resistance of a square mesh

*An N × N mesh of resistors each of value R has edge-to-edge resistance R,
independent of N.*

**Proof.** Hold opposite edges at fixed potentials. By symmetry no current
flows transversely, so the mesh is exactly N parallel chains of N resistors in
series: `(N·R)/N = R`. ∎

So sheet resistance is one segment's resistance per square — 375 Ω/sq here.
This gave the independent order-of-magnitude check on the 834 Ω figure.

### Strap ladder

`nbWid` parallel chains of `nbLen` series elements:

```
R_strap = nbLen · R_element / nbWid
```

25 MΩ elements, 5 × 2 ⟹ 10 MΩ per strap, two in parallel ⟹ 5 MΩ.

### Equilibrium charging

Ohm's law on the total collected current: `V = J·A·R`.
10 µA/m² × 0.38 m² × 5 MΩ = **19 V**.

### Stored energy

`E = ½CV²` = ½ × 1 nF × (11 kV)² = **60 mJ**.

### RC corner

Strap resistance in parallel with panel capacitance:

```
Z = R/(1 + jωRC),    |Z| = R/√(1 + (ωRC)²)
```

At `ωRC = 1` the magnitude is `R/√2` (−3 dB):

```
f_c = 1/(2πRC) = 31.8 Hz    for 5 MΩ and 1 nF
```

Above it `|Z| ≈ 1/(ωC)`: −20 dB/decade, phase −90°.

---

## 10. Verification

Theory is not proof that the code implements it. Three independent checks:

| check | what it establishes | result |
|---|---|---|
| `esd_verify_ltspice` | the matrix assembly and solve reproduce SPICE | 8.9 × 10⁻⁷ |
| `esd_verify_ac` | same, complex, magnitude and phase | 9.2 × 10⁻⁶ |
| `smoke_test` | min R equals the strap floor exactly; symmetry | machine precision |

Both verifiers build their netlist **from the same element list** the matrix is
assembled from. They therefore confirm the linear algebra, not the topology —
which was reconstructed from photographs of `Generate1.m` and is bounded
separately by `compare_legacy` (worst deviation 0.0012 %).

The `smoke_test` lower bound deserves note: the minimum resistance anywhere on
the sheet comes out at exactly `nbLen·R/nbWid/nStraps`, the strap network in
parallel. No point can be closer to structure than the straps themselves, and
the solver reproduces that bound to machine precision.

---

## 11. Complexity summary

With `N` nodes and `M` measurement points (here both ≈ 3,283):

| step | cost |
|---|---|
| assembly | `O(E)`, E = number of elements |
| ordering (AMD / nested dissection) | `O(N log N)` typical |
| factorisation | `O(N^1.5)` for a 2-D mesh |
| each solve | `O(nnz(L))` |
| all M solves | `M · O(nnz(L))` |

`Generate1.m` was `M · O(N^1.5)` plus a process launch and a file parse per
point. Same circuit, same answer — the difference is entirely in not throwing
the factorisation away.
