function esd_verify(what, a, b)
% Checks on the solver.
%
%   esd_verify              run everything
%   esd_verify('sanity')    symmetry, bounds, node counts
%   esd_verify('legacy')    deviation from Generate1.m
%   esd_verify('spice')     cross-check DC and AC against LTspice
%   esd_verify('node', w,l) print every element attached to one node

if nargin < 1 || isempty(what), what = 'all'; end

switch what
case 'all'
    esd_verify('sanity'); esd_verify('legacy'); esd_verify('spice');
case 'sanity',  sanity();
case 'legacy',  legacy();
case 'spice',   spice();
case 'node',    nodeReport(a, b);
otherwise,      error('esd_verify:what', 'Unknown check "%s".', what);
end
end

% -----------------------------------------------------------------------
function sanity()
fprintf('\n== sanity ==\n');
p = esd_config();
[A, info] = esd_solve(p);

% Two straps on the centreline, so the map must be symmetric in L.  In W it
% is only nearly symmetric: contacts land at 480 and 510 mm on a grid whose
% centre is 510 mm, because the node count rounds up past the 1000 mm sheet.
relL = max(abs(A(:) - reshape(A(:,end:-1:1),[],1)) ./ max(abs(A(:)),1), [], 'omitnan');
relW = max(abs(A(:) - reshape(A(end:-1:1,:),[],1)) ./ max(abs(A(:)),1), [], 'omitnan');
fprintf('  symmetry residual   L %.3e, W %.3e\n', relL, relW);

% Nothing can sit closer to structure than the straps in parallel.
floorR = p.nbLen*p.rStrapEach/p.nbWid / nnz(p.strapPosMM);
fprintf('  min R %.6g vs strap floor %.6g  (ratio %.9f)\n', ...
        info.minR, floorR, info.minR/floorR);
fprintf('  NaN fraction (bare substrate) %.3f\n', mean(isnan(A(:))));

% The charging solve should converge onto 0.0737*J*rho_s*a^2 as the
% sub-grid refines.
fprintf('  charging vs analytic:');
for g = [3 7 11]
    [~, ic] = esd_solve(esd_config('gap',g,'substrateRes',1e13), 'charge', 10e-6);
    fprintf('  gap %u -> %.4f', g, ic.maxSubstrateV/(ic.analytic + ic.maxThreadV));
end
fprintf('\n');
end

% -----------------------------------------------------------------------
function legacy()
fprintf('\n== deviation from Generate1.m ==\n');
p = esd_config();
step = p.gap + 1;

% Generate1.m marked a node for measurement only if it had an OUTGOING
% edge.  That misses exactly one node, the far corner - which is what its
% line 183, AreaPlot(TmpW,TmpL)=1, adds back.
[Wg, Lg] = ndgrid(1:p.nW, 1:p.nL);
legacyM = ((mod(Wg-1,step)==0) & (Lg<p.nL)) | ((mod(Lg-1,step)==0) & (Wg<p.nW));
net = esd_network(p);
d = xor(legacyM, net.gridRow > 0);
fprintf('  measured nodes  legacy %u, here %u, differing %u\n', ...
        nnz(legacyM), nnz(net.gridRow>0), nnz(d));
if any(d(:))
    [dw, dl] = find(d);
    fprintf('  differing at %s (the node line 183 restores)\n', mat2str([dw dl]));
end

% Clamp placement: footprint vs floor()ed anchor.
A1 = esd_solve(p);
q = p;  q.legacyClamp = true;
A2 = esd_solve(q);
rel = max(abs(A1(:)-A2(:))./A2(:), [], 'omitnan');
fprintf('  clamp placement worst difference %.3e (%.4f%%)\n', rel, 100*rel);
end

% -----------------------------------------------------------------------
function spice()
% LTspice 26 notes: it rejects '.dc I1 list 1' as a one-point sweep, which
% is what Generate1.m emitted, so a two-point list is used.  Batch mode
% returns status 1 even on success, so the log is the only indicator.
% Results come from .meas rather than the .raw, whose format changed.
exe = fullfile(getenv('LOCALAPPDATA'),'Programs','ADI','LTspice','LTspice.exe');
if ~isfile(exe)
    fprintf('\n== LTspice == not found at %s, skipping\n', exe);
    return;
end
fprintf('\n== LTspice cross-check ==\n');

p   = esd_config();
net = esd_network(p);
d   = fullfile(tempdir,'esd_verify');
if ~exist(d,'dir'), mkdir(d); end
nm  = @(i) sprintf('N%06u', i);

for ac = [false true]
    if ac, f = 1e6;  Zm = esd_solve(p,'z',f);  else, f = 0;  Zm = esd_solve(p); end
    live = find(net.gridRow > 0);
    rng(0);
    pick = live(randperm(numel(live), 4));
    err  = zeros(4,1);

    for k = 1:4
        [w,l] = ind2sub([p.nW p.nL], pick(k));
        nf = fullfile(d, sprintf('c%u.net',k));
        lf = fullfile(d, sprintf('c%u.log',k));
        if isfile(lf), delete(lf); end

        fid = fopen(nf,'w');
        fprintf(fid,'* node %u,%u\n', w, l);
        for e = 1:numel(net.ea)
            if ac
                fprintf(fid,'R%u %s M%u %.12g\nL%u M%u %s %.12g\n', ...
                        e, nm(net.ea(e)), e, net.eR(e), e, e, nm(net.eb(e)), net.eL(e));
            else
                fprintf(fid,'R%u %s %s %.12g\n', e, nm(net.ea(e)), nm(net.eb(e)), net.eR(e));
            end
        end
        for e = 1:numel(net.gNode)
            if ac
                fprintf(fid,'RG%u %s G%u %.12g\nLG%u G%u 0 %.12g\n', ...
                        e, nm(net.gNode(e)), e, net.gR(e), e, e, net.gL(e));
            else
                fprintf(fid,'RG%u %s 0 %.12g\n', e, nm(net.gNode(e)), net.gR(e));
            end
        end
        tgt = nm(pick(k));
        if ac
            nz = find(net.nodeC > 0);
            for e = 1:numel(nz)
                fprintf(fid,'C%u %s 0 %.12g\n', e, nm(nz(e)), net.nodeC(nz(e)));
            end
            fprintf(fid,'I1 0 %s AC 1\n.ac list %.12g\n', tgt, f);
            fprintf(fid,'.meas ac zz FIND V(%s) AT %.12g\n', tgt, f);
        else
            fprintf(fid,'I1 0 %s 1\n.dc I1 list 0 1\n', tgt);
            fprintf(fid,'.meas dc zz FIND V(%s) AT 1\n', tgt);
        end
        fprintf(fid,'.backanno\n.end\n');
        fclose(fid);

        system(sprintf('"%s" -b "%s"', exe, nf));
        if ~isfile(lf), error('esd_verify:spice','No log for node %u,%u', w, l); end
        txt = fileread(lf);
        if ac
            tk = regexp(txt,'zz[^=]*=\s*\(?([-\d.eE+]+)dB,([-\d.eE+]+).\)?','tokens','once');
            Zs = 10^(str2double(tk{1})/20) * exp(1i*str2double(tk{2})*pi/180);
        else
            tk = regexp(txt,'zz[^=]*=\s*([-\d.eE+]+)','tokens','once');
            Zs = str2double(tk{1});
        end
        err(k) = abs(Zm(w,l) - Zs)/abs(Zs);
    end

    if ac, lbl = sprintf('AC %g Hz', f); else, lbl = 'DC'; end
    fprintf('  %-12s worst relative error %.3e over 4 nodes\n', lbl, max(err));
end
end

% -----------------------------------------------------------------------
function nodeReport(w, l)
p   = esd_config();
net = esd_network(p);
step = p.gap + 1;
id  = (l-1)*p.nW + w;
nm  = @(i) local_name(i, p);

fprintf('\nNode (w=%u, l=%u), id %u\n', w, l, id);
fprintf('  thread along L: %s,  thread along W: %s\n', ...
        yn(mod(w-1,step)==0), yn(mod(l-1,step)==0));
if net.gridRow(w,l) == 0
    fprintf('  not in the network - no element touches it\n');  return;
end

hit = find(net.ea == id | net.eb == id);
fprintf('  %u series branches (R in series with L):\n', numel(hit));
for e = hit(:)'
    other = net.eb(e);  if other == id, other = net.ea(e); end
    fprintf('    -> %-14s R = %-10.4g L = %.4g\n', nm(other), net.eR(e), net.eL(e));
end
if net.nodeC(id) > 0
    fprintf('  shunt to structure: C = %.4g F\n', net.nodeC(id));
end
for e = find(net.gNode == id)'
    fprintf('  tie to structure:   R = %.4g, L = %.4g\n', net.gR(e), net.gL(e));
end
end

function s = local_name(i, p)
if i <= p.nW*p.nL
    s = sprintf('sheet %u,%u', mod(i-1,p.nW)+1, floor((i-1)/p.nW)+1);
else
    s = sprintf('strap %u', i - p.nW*p.nL);
end
end

function s = yn(t)
if t, s = 'yes'; else, s = 'no'; end
end
