function p = esd_config(varargin)
% Parameters for the CS-1 dissipative sheet model.
%
%   p = esd_config()
%   p = esd_config('rStrapEach', 50e6, 'gap', 7)
%
% Defaults match the 2026-09-08 run: 1000 x 380 mm sheet, threads on a
% 30 mm pitch, bonded at both 380 mm ends.

% Sheet
p.linRes     = 12500;   % ohm/m of dissipative thread
p.threadSep  = 30;      % mm between threads
p.gap        = 3;       % sub-segments per pitch, minus one
p.sheetW     = 1000;    % mm, W axis
p.sheetL     = 380;     % mm, L axis

% Bonding straps.  One row per W position, columns are the two sheet ends
% (l = 1, l = nL).  Zero excludes a strap.  Same convention as DisPos.
p.strapPosMM = [500 500];
p.barWidth   = 60;      % mm, clamping bar
p.nbWid      = 5;       % parallel chains per strap
p.nbLen      = 2;       % series elements per chain
p.rStrapEach = 25e6;    % ohm per strap element
p.rGndToStrap= 10e-3;   % ohm, structure to strap
p.rBarBond   = 10e-3;   % ohm, bar to sheet

% Substrate between threads, ohm/sq.  Finite values activate the grid
% positions between threads as nodes; Inf leaves the thread-only network.
% Polymer resistivity moves orders of magnitude with temperature, field and
% radiation, so any single value is a placeholder.  1e13 puts cell centres
% near 11 kV.
p.substrateRes = Inf;

% Reactive.  All vanish at DC.  panelCap is spread equally over live nodes.
p.panelCap   = 1e-9;    % F, total sheet to structure
p.linInd     = 1e-6;    % H/m of thread
p.strapInd   = 1e-6;    % H per strap element
p.bondInd    = 1e-9;    % H per bond

p.esdVolts   = 11000;   % V, from PeakContactPotential

for k = 1:2:numel(varargin)
    if ~isfield(p, varargin{k})
        error('esd_config:badField', 'Unknown parameter "%s".', varargin{k});
    end
    p.(varargin{k}) = varargin{k+1};
end

% Derived
step      = p.gap + 1;
p.sideRes = p.linRes * p.threadSep / 1000;   % ohm per pitch
p.segRes  = p.sideRes / step;                % ohm per sub-segment
p.segLen  = p.threadSep / 1000 / step;       % m
p.segInd  = p.linInd * p.segLen;             % H

% Node counts, rounded up to a whole number of pitches.  Matches
% Generate1.m lines 64-71.
nW = (p.sheetW / p.threadSep) * step;
nL = (p.sheetL / p.threadSep) * step;
nW = max(nW, 2);  nL = max(nL, 2);
p.nW = ceil((nW - 1)/step)*step + 1;
p.nL = ceil((nL - 1)/step)*step + 1;
end
