# CS-1 dissipative sheet — ESD model

Successor to `Generate1.m` / `plot_result.m` (2026-09-08). A 1000 × 380 mm
dissipative sheet: conductive threads on a 30 mm grid at 12.5 kΩ/m, bonded to
structure at both 380 mm ends through resistive straps.

Same network and geometry as last year, but solved directly as a sparse
system instead of one LTspice run per node — 2.5 s rather than hours — and
extended to cover charging, impedance and the discharge transient.

## Running it

```matlab
run_esd        % everything: DC sweep, charging, impedance, transient, margins
ESD_Model      % standalone DC-only version, one file
esd_verify     % sanity checks, deviation from Generate1.m, LTspice
```

`run_esd.m` is split into sections — run them individually with Ctrl+Enter.
Output goes to `results/`.

## Files

| file | purpose |
|---|---|
| `esd_config.m` | Parameters. |
| `esd_network.m` | Element list, and the nodal matrix at any frequency. |
| `esd_solve.m` | DC resistance, impedance, and equilibrium charging. |
| `esd_transient.m` | Time domain, self-discharge or IEC 61000-4-2 gun. |
| `esd_plot.m` | Sheet maps in millimetres. |
| `esd_verify.m` | Checks. `esd_verify('node',w,l)` inspects one node. |
| `run_esd.m` | The analyses. |
| `ESD_Model.m` | Standalone DC model, self-contained. |

`THEORY.md` has the derivations.

## Why it is fast

1 A into node *k* gives `V_k = R_k`, the k-th diagonal entry of `inv(G)`.
Every injection point shares `G`, so one Cholesky factorisation answers all
3,283. `Generate1.m` re-solved from scratch per node: 19,698 LTspice runs
across the sweep.

The same trick appears twice more — the transient's companion models keep the
matrix constant within a stage, and the charging solve needs one right-hand
side instead of 3,283.

## Results

**DC resistance.** 1–10 MΩ depending on case, varying 0.02% across the sheet.
The straps set it; the sheet adds at most 834 Ω.

**Charging.** At 10 µA/m² with ρs = 10¹³ Ω/sq: threads at **20 V**, substrate
between them at **6.6 kV**. Scales as thread pitch squared — 15 mm gives
1.6 kV, 60 mm gives 25 kV. `PeakContactPotential = 11000` corresponds to
ρs = 1.7×10¹³ Ω/sq, an ordinary polymer value, so the 11 kV is differential
charging of the substrate rather than the threads.

**Impedance.** Panel capacitance shunts the straps out above 32 Hz (1 nF
against 5 MΩ); |Z| falls 20 dB/decade to a few hundred ohms. Inductance only
matters above 2 GHz.

**Transient.** 11 kV on 0.673 nF: 74.7 A peak, drains in ~1 µs, 97.8% of the
40.7 mJ into the threads rather than the arc. Worst thread segment takes
1.1 mJ for a 98 K adiabatic rise, 37× margin.

## Conclusions

The straps work — they hold the threads at 20 V against a kilovolt threshold,
and across eight decades of strap resistance the charging voltage moves five
orders of magnitude. 10, 25 and 50 MΩ all pass comfortably.

They cannot influence a discharge. Peak current is identical to four
significant figures across those same eight decades: the arc peaks in ~1 ns
and the straps are 500 mm away.

Thread pitch is the lever that matters. Differential charging goes as pitch²,
so 30 → 15 mm cuts it 4×. Strap resistance does nothing for it.

Breakdown is an input, not an output. `esd_transient` starts with the arc
already conducting. 11 kV over a 5 mm standoff is 2.2 MV/m — well below bulk
polyimide breakdown, but inside the surface-flashover band.

## Validation

| check | result |
|---|---|
| DC vs LTspice | 8.9e-7 |
| AC vs LTspice, magnitude and phase | 9.2e-6 |
| Transient vs LTspice `.tran` | 0.8% |
| Charge balance | 100.00% |
| Energy balance | 100.0% |
| Charging vs analytic 0.0737·J·ρs·a² | converges to 1.0000 |
| Deviation from `Generate1.m` | 0.0012% |

These confirm the linear algebra, not the physics. Nothing has been compared
against hardware.

## Known gaps

* **ρs is the most important unknown.** It sets the charging result linearly
  and moves orders of magnitude with temperature, field and radiation. The
  1e13 default is a placeholder.
* Structure is ideal ground, so there is no harness-coupling mechanism —
  usually the real damage path.
* No thread-to-thread capacitance, dielectric loss, or mutual inductance.
* Thread material properties are inferred from the quoted 12.5 kΩ/m, not
  measured.
* The topology was reconstructed from photographs of `Generate1.m`, since the
  originals were not on this machine. `esd_verify('legacy')` bounds the
  disagreement.

## LTspice notes

Installed here is **26.0.2** at `%LOCALAPPDATA%\Programs\ADI\LTspice\`, not
the `C:\Program Files\LTC\LTspiceXVII\XVIIx64.exe` hardcoded in `Generate1.m`.

Version 26 rejects `.dc I1 list 1` as a one-point sweep, which is exactly
what `Generate1.m` emitted, so the checks use a two-point list. Batch mode
returns exit status 1 even on success, so the log has to be read rather than
the status code. Results come from `.meas` lines in the `.log` — the `.raw`
format changed between XVII and 26.

## Version control

`git checkout dc-baseline` returns to the verified DC-only model.
