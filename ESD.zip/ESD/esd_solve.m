function [M, info] = esd_solve(p, mode, arg)
% Steady-state solves on the sheet network.
%
%   [R, info] = esd_solve(p)                    DC resistance to structure
%   [Z, info] = esd_solve(p, 'z', 1e6)          impedance at 1 MHz, complex
%   [V, info] = esd_solve(p, 'charge', 10e-6)   potential under J A/m^2
%
% Returns an nW-by-nL map, NaN where the sheet carries no node.
%
% 'z' injects 1 A at one node at a time: V_k = Z_k = (inv(Y))_kk.  All the
% injection points share Y, so one factorisation serves all ~3300 of them.
% 'charge' injects J*area at every node simultaneously - same matrix, but
% only one right-hand side.

if nargin < 2 || isempty(mode), mode = 'z';  end
if nargin < 3 || isempty(arg)
    if strcmp(mode, 'charge'), arg = 10e-6; else, arg = 0; end
end

t0  = tic;
net = esd_network(p);
idx  = find(net.gridRow > 0);
rows = net.gridRow(idx);
n    = net.n;

switch mode
case 'z'
    [Y, isReal] = esd_network(net, arg);
    if isReal
        dY = decomposition(Y, 'chol');      % SPD at DC
    else
        dY = decomposition(Y, 'lu');        % complex symmetric, not Hermitian
    end

    nM = numel(idx);
    Z  = zeros(nM, 1);
    if ~isReal, Z = complex(Z); end
    blk = 512;                              % blocked so the solves hit BLAS-3
    for s = 1:blk:nM
        e    = min(s + blk - 1, nM);
        cols = rows(s:e);
        nc   = numel(cols);
        E    = full(sparse(cols, 1:nc, 1, n, nc));
        X    = dY \ E;
        Z(s:e) = X(sub2ind([n nc], cols(:), (1:nc)'));
    end

    M = nan(p.nW, p.nL);
    if ~isReal, M = complex(M, nan); end
    M(idx) = Z;

    info = struct('mode','z', 'freq',arg, 'nNodes',nM, 'nUnknowns',n, ...
                  'straps',net.straps, 'minR',min(abs(Z)), 'maxR',max(abs(Z)));
    info.spreadPct = 100*(info.maxR - info.minR)/info.minR;

case 'charge'
    Y = esd_network(net, 0);
    step     = p.gap + 1;
    nodeArea = (p.threadSep/1000/step)^2;

    i = zeros(n, 1);
    i(rows) = arg * nodeArea;

    % 93.75 ohm threads against a 1e13 ohm/sq substrate is a conductance
    % ratio of 1e11 sitting on the diagonal, which destroys the
    % conditioning.  Symmetric equilibration fixes it and leaves the
    % solution unchanged: (SYS)(inv(S)v) = Si with S = diag(Y)^(-1/2).
    S  = spdiags(1./sqrt(full(diag(Y))), 0, n, n);
    Ys = S*Y*S;
    Ys = (Ys + Ys')/2;          % exactly symmetric in theory, not in floats
    V  = S * (decomposition(Ys, 'chol') \ (S*i));

    M = nan(p.nW, p.nL);
    M(idx) = V(rows);

    [Wg, Lg] = ndgrid(1:p.nW, 1:p.nL);
    onThread = (mod(Wg-1, step) == 0) | (mod(Lg-1, step) == 0);
    subV     = M(~onThread & ~isnan(M));

    info = struct('mode','charge', 'J',arg, 'nNodes',numel(idx), ...
                  'straps',net.straps, 'nodeArea',nodeArea, ...
                  'maxV',max(M(:),[],'omitnan'), ...
                  'maxThreadV',max(M(onThread & ~isnan(M)),[],'omitnan'), ...
                  'maxSubstrateV',max(subV,[],'omitnan'), ...
                  'rcond',1/condest(Ys));
    % V = 0.0737*J*rho_s*a^2 is the rise above the thread boundary.
    if isfinite(p.substrateRes)
        info.analytic = 0.07367 * arg * p.substrateRes * (p.threadSep/1000)^2;
    else
        info.analytic = NaN;
    end
    if info.rcond < 1e-14
        warning('esd_solve:conditioning', ...
                'rcond %.3g after equilibration - treat as indicative.', info.rcond);
    end

otherwise
    error('esd_solve:mode', 'mode must be ''z'' or ''charge''.');
end

info.elapsed = toc(t0);
end
