function varargout = esd_network(p, f)
% Element list and nodal matrix for the sheet.
%
%   net = esd_network(p)        build the element list
%   Y   = esd_network(net, f)   assemble the matrix at f Hz (f = 0 is real)
%
% net fields:
%   ea, eb, eR, eL    series branches and their R and L
%   gNode, gR, gL     ties to structure
%   nodeC             shunt capacitance per node
%   gridRow           nW-by-nL, matrix row for each sheet position, 0 if none
%   live, row, n      node bookkeeping

if isfield(p, 'ea')                 % already a net: assemble the matrix
    if nargin < 2, f = 0; end
    [Y, isReal] = assemble(p, f);
    varargout = {Y, isReal};
else                                % parameter struct: build the element list
    varargout = {build(p)};
end
end

% -----------------------------------------------------------------------
function net = build(p)

step  = p.gap + 1;
nW    = p.nW;  nL = p.nL;
nGrid = nW * nL;

wRows = 1:step:nW;          % threads running along L
lCols = 1:step:nL;          % threads running along W

[Wr, Lr] = ndgrid(wRows, 1:nL-1);
ea = (Lr(:)-1)*nW + Wr(:);
eb = (Lr(:)  )*nW + Wr(:);

[Wv, Lv] = ndgrid(1:nW-1, lCols);
ea = [ea; (Lv(:)-1)*nW + Wv(:)];
eb = [eb; (Lv(:)-1)*nW + Wv(:) + 1];

eR = repmat(p.segRes, numel(ea), 1);
eL = repmat(p.segInd, numel(ea), 1);

% Substrate mesh over every adjacent pair, including alongside threads.
% Each link is rho_s regardless of pitch, since a square patch of sheet has
% resistance rho_s at any size.  sparse() sums duplicates, so links next to
% a thread end up correctly in parallel with it.
if isfinite(p.substrateRes) && p.substrateRes > 0
    [Sw, Sl] = ndgrid(1:nW-1, 1:nL);
    sa = (Sl(:)-1)*nW + Sw(:);
    sb = (Sl(:)-1)*nW + Sw(:) + 1;
    [Tw, Tl] = ndgrid(1:nW, 1:nL-1);
    sa = [sa; (Tl(:)-1)*nW + Tw(:)];
    sb = [sb; (Tl(:)  )*nW + Tw(:)];

    ea = [ea; sa];  eb = [eb; sb];
    eR = [eR; repmat(p.substrateRes, numel(sa), 1)];
    eL = [eL; repmat(p.segInd, numel(sa), 1)];   % non-zero: transient divides by 2L
end

% Straps: nbWid chains of nbLen elements between a tie to structure and a
% clamping bar that touches every thread under its footprint.
nExtraPer = 2 + p.nbWid*(p.nbLen - 1);
next      = nGrid;
rowMM     = (wRows - 1)/step * p.threadSep;

gNode = zeros(0,1);  gR = zeros(0,1);  gL = zeros(0,1);
straps = struct('posMM', {}, 'lNode', {}, 'contacts', {}, 'contactMM', {});

[nPos, nEnd] = size(p.strapPosMM);
for r = 1:nPos
    for c = 1:nEnd
        posMM = p.strapPosMM(r, c);
        if posMM == 0, continue; end
        lEdge = 1;  if c == 2, lEdge = nL; end

        if isfield(p, 'legacyClamp') && p.legacyClamp
            % Generate1.m: floor()ed anchor, then step off it.  Can land on
            % a position with no thread, and biases low by up to a pitch.
            nPts     = max(1, floor(p.barWidth / p.threadSep));
            anchor   = floor((posMM / p.threadSep) * step);
            contacts = anchor + (0:nPts-1)*step;
            contacts = contacts(contacts >= 1 & contacts <= nW);
        else
            contacts = wRows(abs(rowMM - posMM) <= p.barWidth/2 + 1e-9);
            if isempty(contacts)
                [~, kk]  = min(abs(rowMM - posMM));
                contacts = wRows(kk);
            end
        end

        nStart  = next + 1;
        nBar    = next + 2;
        intBase = next + 2;
        next    = next + nExtraPer;

        gNode(end+1,1) = nStart;          %#ok<AGROW>
        gR(end+1,1)    = p.rGndToStrap;   %#ok<AGROW>
        gL(end+1,1)    = p.bondInd;       %#ok<AGROW>

        for m = 1:p.nbWid
            for k = 1:p.nbLen
                if k == 1,        A = nStart;
                else,             A = intBase + (m-1)*(p.nbLen-1) + (k-1);
                end
                if k == p.nbLen,  B = nBar;
                else,             B = intBase + (m-1)*(p.nbLen-1) + k;
                end
                ea(end+1,1) = A;  eb(end+1,1) = B;      %#ok<AGROW>
                eR(end+1,1) = p.rStrapEach;             %#ok<AGROW>
                eL(end+1,1) = p.strapInd;               %#ok<AGROW>
            end
        end

        for wc = contacts
            ea(end+1,1) = nBar;                         %#ok<AGROW>
            eb(end+1,1) = (lEdge-1)*nW + wc;            %#ok<AGROW>
            eR(end+1,1) = p.rBarBond;                   %#ok<AGROW>
            eL(end+1,1) = p.bondInd;                    %#ok<AGROW>
        end

        straps(end+1) = struct('posMM', posMM, 'lNode', lEdge, ...
            'contacts', contacts, ...
            'contactMM', (contacts-1)/step*p.threadSep);   %#ok<AGROW>
    end
end

nAll = next;

% Drop positions carrying no element - they would give a zero row and make
% the matrix singular.  Decided resistively so DC and AC cover the same set.
dg   = accumarray([ea; eb], [1./eR; 1./eR], [nAll 1]);
dg   = dg + accumarray(gNode, 1./gR, [nAll 1], [], 0);
live = dg > 0;
nl   = nnz(live);

row       = zeros(nAll, 1);
row(live) = 1:nl;

nodeC      = zeros(nAll, 1);
liveSheet  = find(live(1:nGrid));
nodeC(liveSheet) = p.panelCap / numel(liveSheet);

net = struct('ea', ea, 'eb', eb, 'eR', eR, 'eL', eL, ...
             'gNode', gNode, 'gR', gR, 'gL', gL, 'nodeC', nodeC, ...
             'live', live, 'row', row, 'n', nl, 'nAll', nAll, ...
             'gridRow', reshape(row(1:nGrid), nW, nL), ...
             'straps', straps, 'p', p);
end

% -----------------------------------------------------------------------
function [Y, isReal] = assemble(net, f)
% Nodal matrix at f Hz.  Structure is at 0 V and eliminated, so a grounded
% node carries its conductance on the diagonal with no off-diagonal partner.
if nargin < 2 || isempty(f), f = 0; end
w = 2*pi*f;

if w == 0
    ye = 1./net.eR;   yg = 1./net.gR;   isReal = true;
else
    ye = 1./(net.eR + 1i*w*net.eL);
    yg = 1./(net.gR + 1i*w*net.gL);
    isReal = false;
end

nAll = net.nAll;
offd = sparse([net.ea; net.eb], [net.eb; net.ea], [-ye; -ye], nAll, nAll);
dg   = accumarray([net.ea; net.eb], [ye; ye], [nAll 1]);
dg   = dg + accumarray(net.gNode, yg, [nAll 1], [], 0);
if ~isReal, dg = dg + 1i*w*net.nodeC; end

L = net.live;  n = net.n;
Y = offd(L, L) + spdiags(dg(L), 0, n, n);
end
