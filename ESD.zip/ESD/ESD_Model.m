%% DC resistance to structure for the CS-1 dissipative sheet.
%
%  Standalone version of the resistor model - nothing else needed to run it.
%  Successor to Generate1.m: same network and geometry, but solved as a
%  sparse system rather than one LTspice run per node.
%
%  1 A into node k gives V_k = R_k, the k-th diagonal entry of inv(G).  All
%  the injection points share G, so one factorisation serves all 3283.
%
%  DC only.  Capacitance, inductance, charging and the transient are in
%  run_esd.m.  Six cases, about 2.5 seconds.

clear; close all; clc;


%% ======================================================================
%  PARAMETERS
%  ======================================================================

% ---- dissipative sheet ----
CSaryLinRes    = 12500;    % Ohms per linear metre of dissipative thread
CSaryThreadSep = 30;       % mm between dissipative threads
CSaryGap       = 3;        % sub-segments per thread pitch, minus one
CSaryWidth     = 1000;     % mm, creepage distance along the W axis
CSaryLength    = 380;      % mm, the L axis

% ---- bonding straps ----
% One row per W position, two columns = the two sheet ends (l = 1, l = nL).
% A zero excludes that strap.  Same convention as Generate1.m's DisPos.
DisBarWidth    = 60;       % mm, width of the clamping bar
DisAryWid      = 5;        % parallel chains inside one strap
DisAryLen      = 2;        % series elements per chain
N0toNbond      = 10e-3;    % Ohms, structure to strap
DisBarBond     = 10e-3;    % Ohms, clamping bar to sheet

% ---- the sweep ----
SweepRes   = [10e6 25e6 50e6];             % strap element resistance
SweepStrap = { [500 500],          '2straps'
               [200 200; 740 740], '4straps' };

% ---- output ----
SavePNG    = true;
OutDir     = 'results';


%% ======================================================================
%  DERIVED QUANTITIES
%  ======================================================================

step         = CSaryGap + 1;
CSarySideRes = CSaryLinRes * CSaryThreadSep / 1000;   % Ohms per thread pitch
CSaryRes     = CSarySideRes / step;                   % Ohms per sub-segment

% Node counts, rounded up to a whole number of thread pitches (+1 for the
% closing node).  Reproduces lines 64-71 of Generate1.m exactly.
nWtmp = (CSaryWidth  / CSaryThreadSep) * step;
nLtmp = (CSaryLength / CSaryThreadSep) * step;
if nWtmp <= 1, nWtmp = 2; end
if nLtmp <= 1, nLtmp = 2; end
CSaryWid = ceil((nWtmp - 1)/step)*step + 1;
CSaryLen = ceil((nLtmp - 1)/step)*step + 1;

fprintf('Grid %u x %u nodes, %g Ohms per sub-segment (%g Ohms per %g mm pitch)\n\n', ...
        CSaryWid, CSaryLen, CSaryRes, CSarySideRes, CSaryThreadSep);

% Pack everything the helper functions need into one struct.
p = struct('nW', CSaryWid, 'nL', CSaryLen, 'step', step, ...
           'threadSep', CSaryThreadSep, 'segRes', CSaryRes, ...
           'barWidth', DisBarWidth, 'nbWid', DisAryWid, 'nbLen', DisAryLen, ...
           'rGndToStrap', N0toNbond, 'rBarBond', DisBarBond, ...
           'rStrapEach', SweepRes(1), 'strapPosMM', SweepStrap{1,1});

if SavePNG && ~exist(OutDir, 'dir'), mkdir(OutDir); end


%% ======================================================================
%  SWEEP
%  ======================================================================

Results = struct('tag', {}, 'AreaPlot', {}, 'info', {}, 'p', {});

for ri = 1:numel(SweepRes)
    for si = 1:size(SweepStrap, 1)

        p.rStrapEach = SweepRes(ri);
        p.strapPosMM = SweepStrap{si,1};
        tag = sprintf('results_%gMOhm_%s', SweepRes(ri)/1e6, SweepStrap{si,2});

        net = buildNetwork(p);
        [AreaPlot, info] = solveMap(net);

        fprintf('%-24s %5u nodes  %.4f to %.4f MOhm  (spread %.3f%%)  [%.2f s]\n', ...
                tag, info.nNodes, info.minR/1e6, info.maxR/1e6, ...
                info.spreadPct, info.elapsed);

        Results(end+1) = struct('tag', tag, 'AreaPlot', AreaPlot, ...
                                'info', info, 'p', p);   %#ok<SAGROW>

        if SavePNG
            save(fullfile(OutDir, [tag '.mat']), 'AreaPlot', 'p', 'info');
        end
    end
end


%% ======================================================================
%  PLOTS -- one figure per case, as plot_result.m did
%  ======================================================================

for k = 1:numel(Results)
    fig = figure('Name', Results(k).tag, 'Position', [60+18*k 60+14*k 900 460]);
    drawMap(Results(k).AreaPlot/1e6, Results(k).p, Results(k).info.straps);
    colormap(turbo); cb = colorbar;
    cb.Label.String = 'R to structure  (M\Omega)';
    title([char(strrep(Results(k).tag, '_', '  ')) ...
           sprintf('   %.4f to %.4f M', Results(k).info.minR/1e6, ...
                   Results(k).info.maxR/1e6) '\Omega' ...
           sprintf('  (spread %.3f%%)', Results(k).info.spreadPct)]);
    ax = gca; ax.Toolbar.Visible = 'off';
    if SavePNG
        exportgraphics(fig, fullfile(OutDir, [Results(k).tag '.png']), ...
                       'Resolution', 200);
    end
end

fprintf('\nDone.\n');


%% ======================================================================
%  LOCAL FUNCTIONS
%  ======================================================================

function net = buildNetwork(p)
% Walk the geometry and list every resistor.

step  = p.step;
nW    = p.nW;
nL    = p.nL;
nGrid = nW * nL;

% ---- sheet: one resistor per sub-segment along every thread ----
% Threads run along L on rows w = 1, 1+step, ... and along W on columns
% l = 1, 1+step, ...  Everything else is bare substrate with no node.
wRows = 1:step:nW;
lCols = 1:step:nL;

[Wr, Lr] = ndgrid(wRows, 1:nL-1);          % threads along L
ea = (Lr(:)-1)*nW + Wr(:);
eb = (Lr(:)  )*nW + Wr(:);

[Wv, Lv] = ndgrid(1:nW-1, lCols);          % threads along W
ea = [ea; (Lv(:)-1)*nW + Wv(:)];
eb = [eb; (Lv(:)-1)*nW + Wv(:) + 1];

eR = repmat(p.segRes, numel(ea), 1);

% ---- bonding straps ----
nExtraPer = 2 + p.nbWid*(p.nbLen - 1);
next      = nGrid;
rowMM     = (wRows - 1)/step * p.threadSep;     % W position of each thread row

gNode = zeros(0,1);  gR = zeros(0,1);
straps = struct('posMM', {}, 'lNode', {}, 'contacts', {}, 'contactMM', {});

[nPos, nEnd] = size(p.strapPosMM);
for r = 1:nPos
    for c = 1:nEnd
        posMM = p.strapPosMM(r, c);
        if posMM == 0, continue; end

        lEdge = 1;
        if c == 2, lEdge = nL; end

        % The clamping bar spans barWidth centred on posMM and contacts every
        % thread row inside that footprint.  Generate1.m instead took
        % floor((posMM/threadSep)*step) as an anchor and stepped off it, which
        % could put the clamp on a node with no thread through it.
        inBar    = abs(rowMM - posMM) <= p.barWidth/2 + 1e-9;
        contacts = wRows(inBar);
        if isempty(contacts)                    % bar narrower than one pitch
            [~, kk]  = min(abs(rowMM - posMM));
            contacts = wRows(kk);
        end

        nStart  = next + 1;
        nBar    = next + 2;
        intBase = next + 2;
        next    = next + nExtraPer;

        gNode(end+1,1) = nStart;                %#ok<AGROW>
        gR(end+1,1)    = p.rGndToStrap;         %#ok<AGROW>

        for m = 1:p.nbWid                       % nbWid chains of nbLen
            for k = 1:p.nbLen
                if k == 1
                    A = nStart;
                else
                    A = intBase + (m-1)*(p.nbLen-1) + (k-1);
                end
                if k == p.nbLen
                    B = nBar;
                else
                    B = intBase + (m-1)*(p.nbLen-1) + k;
                end
                ea(end+1,1) = A;   eb(end+1,1) = B;      %#ok<AGROW>
                eR(end+1,1) = p.rStrapEach;              %#ok<AGROW>
            end
        end

        for wc = contacts                       % bar down onto the sheet
            ea(end+1,1) = nBar;                          %#ok<AGROW>
            eb(end+1,1) = (lEdge-1)*nW + wc;             %#ok<AGROW>
            eR(end+1,1) = p.rBarBond;                    %#ok<AGROW>
        end

        straps(end+1) = struct('posMM', posMM, 'lNode', lEdge, ...
            'contacts', contacts, ...
            'contactMM', (contacts-1)/step*p.threadSep);  %#ok<AGROW>
    end
end

nAll = next;

% ---- which nodes actually exist ----
% A node with no resistor on it would give a zero row and make G singular,
% so the bare-substrate positions have to be dropped.
dg   = accumarray([ea; eb], [1./eR; 1./eR], [nAll 1]);
dg   = dg + accumarray(gNode, 1./gR, [nAll 1], [], 0);
live = dg > 0;
nl   = nnz(live);

row       = zeros(nAll, 1);
row(live) = 1:nl;

net = struct('ea', ea, 'eb', eb, 'eR', eR, 'gNode', gNode, 'gR', gR, ...
             'live', live, 'row', row, 'n', nl, 'nAll', nAll, ...
             'gridRow', reshape(row(1:nGrid), nW, nL), ...
             'straps', straps, 'p', p);
end


function G = conductance(net)
% Nodal conductance matrix.  G(k,k) is the sum of conductances touching k,
% G(k,j) is -g_kj.  Structure is at 0 V and eliminated, so a grounded node
% carries its conductance on the diagonal with no off-diagonal partner.
% G is SPD (v'*G*v is dissipated power), hence Cholesky below.

ye = 1./net.eR;
yg = 1./net.gR;
nAll = net.nAll;

% sparse() SUMS duplicate (i,j) pairs, which is exactly right for parallel
% resistors between the same two nodes.
offd = sparse([net.ea; net.eb], [net.eb; net.ea], [-ye; -ye], nAll, nAll);
dg   = accumarray([net.ea; net.eb], [ye; ye], [nAll 1]);
dg   = dg + accumarray(net.gNode, yg, [nAll 1], [], 0);

L = net.live;   n = net.n;
G = offd(L, L) + spdiags(dg(L), 0, n, n);
end


function [Rmap, info] = solveMap(net)
% Resistance from every sheet node to structure.
% R_k = (inv(G))_kk, so one factorisation answers every injection point.

t0 = tic;
p  = net.p;
G  = conductance(net);
n  = net.n;

idx  = find(net.gridRow > 0);
rows = net.gridRow(idx);
M    = numel(idx);

dG = decomposition(G, 'chol');      % G is symmetric positive definite

R   = zeros(M, 1);
blk = 512;
for s = 1:blk:M
    e      = min(s + blk - 1, M);
    cols   = rows(s:e);
    nc     = numel(cols);
    E      = full(sparse(cols, 1:nc, 1, n, nc));    % 1 A into each of nc nodes
    X      = dG \ E;
    R(s:e) = X(sub2ind([n nc], cols(:), (1:nc)'));  % voltage at that node
end

Rmap      = nan(p.nW, p.nL);
Rmap(idx) = R;

info = struct('elapsed', toc(t0), 'nNodes', M, 'nUnknowns', n, ...
              'nElements', numel(net.eR) + numel(net.gR), ...
              'straps', net.straps, 'minR', min(R), 'maxR', max(R));
info.spreadPct = 100*(info.maxR - info.minR)/info.minR;
end


function drawMap(A, p, straps)
% One sheet map in millimetres, clamp contacts marked.
x = (0:p.nW-1)/p.step * p.threadSep;
y = (0:p.nL-1)/p.step * p.threadSep;
h = imagesc(x, y, A');
set(h, 'AlphaData', ~isnan(A'));          % bare substrate stays blank
set(gca, 'YDir', 'normal', 'Color', [0.92 0.92 0.92]);
axis image; xlabel('W (mm)'); ylabel('L (mm)');
hold on;
for s = straps
    yl = y(1); if s.lNode > 1, yl = y(end); end
    plot(s.contactMM, repmat(yl, size(s.contactMM)), 'ws', ...
         'MarkerFaceColor', 'k', 'MarkerSize', 5);
end
hold off;
end
