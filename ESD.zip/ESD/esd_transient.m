function out = esd_transient(p, opts)
% Time-domain discharge of the sheet.
%
%   out = esd_transient(p)                              pre-charged, arcs to 0 V
%   out = esd_transient(p, struct('iecVolts', 8))       driven by an ESD gun
%
% opts (all optional):
%   V0        initial panel potential, V            11000
%   Rarc      arc resistance, ohm                   1
%   Larc      discharge LOOP inductance, H          100e-9
%   iecVolts  drive with IEC 61000-4-2 at this kV   [] (self-discharge)
%   iFun      arbitrary injected current, @(t)      []
%   arcNode   [w l] strike point                    sheet centre
%   stages    [h tEnd; ...] integration stages      10 ps to 10 ms
%   probes    {name [w l]; ...} nodes to record
%
% Trapezoidal companion models turn each reactive element into a conductance
% plus a history source, so every timestep is a resistive solve and the
% matrix is constant within a stage - one factorisation per stage.  Still
% SPD, so still Cholesky.  Time constants run 80 ps to 5 ms, which is why
% the step size is staged rather than fixed.
%
% Larc is the loop inductance, not the arc channel alone: roughly 1 nH per
% mm of enclosed path, and a return through structure 5 mm away encloses
% ~100 mm.  It sets the risetime.  At 1 nH the rise is 78 ps, which is not
% physical; 100 nH gives the 0.7-1 ns of a real contact discharge.

if nargin < 2, opts = struct(); end
def = struct('V0',11000, 'Rarc',1, 'Larc',100e-9, 'arcNode',[], ...
             'iFun',[], 'iecVolts',[], 'verbose',true, 'probes',[], ...
             'stages',[1e-11 1e-8; 1e-10 1e-7; 1e-8 1e-5; 1e-6 1e-2]);
fn = fieldnames(def);
for k = 1:numel(fn)
    if ~isfield(opts, fn{k}) || isempty(opts.(fn{k})), opts.(fn{k}) = def.(fn{k}); end
end
if ~isempty(opts.iecVolts)
    opts.iFun = iec_waveform(opts.iecVolts);
    opts.V0   = 0;
end

net  = esd_network(p);
n    = net.n;
step = p.gap + 1;
onT  = @(v) v - mod(v-1, step);

if isempty(opts.arcNode)
    opts.arcNode = [onT(round(p.nW/2)) onT(round(p.nL/2))];
end
if isempty(opts.probes)
    opts.probes = { 'arc',       opts.arcNode
                    'corner',    [1 1]
                    'quarter W', [onT(round(p.nW/4)) onT(round(p.nL/2))]
                    'clamp',     [net.straps(1).contacts(1) 1] };
end

ba = net.row(net.ea);  bb = net.row(net.eb);
bR = net.eR;           bL = net.eL;   nB = numel(bR);
ga = net.row(net.gNode);
gRv = net.gR;          gLv = net.gL;  nG = numel(gRv);
Cn  = net.nodeC(net.live);

arcRow = net.gridRow(opts.arcNode(1), opts.arcNode(2));
if arcRow == 0
    error('esd_transient:arc', 'Node (%u,%u) carries no thread.', opts.arcNode);
end

% A driven source injects current and it returns through the panel's own
% capacitance and the straps, so there is no short to structure.
if isempty(opts.iFun) && isfinite(opts.Rarc)
    ga = [ga; arcRow];  gRv = [gRv; opts.Rarc];  gLv = [gLv; opts.Larc];
    nG = nG + 1;  arcIdx = nG;
else
    arcIdx = 0;
end

pRows = zeros(size(opts.probes,1), 1);
for k = 1:numel(pRows)
    wl = opts.probes{k,2};
    pRows(k) = net.gridRow(wl(1), wl(2));
    if pRows(k) == 0
        error('esd_transient:probe', 'Probe "%s" carries no thread.', opts.probes{k,1});
    end
end

if opts.verbose
    fprintf('%u nodes, %u branches, C = %.4g F\n', n, nB, p.panelCap);
    if arcIdx > 0
        fprintf('Pre-charged to %g V, arc at (%u,%u): %g ohm + %g nH\n\n', ...
                opts.V0, opts.arcNode(1), opts.arcNode(2), opts.Rarc, opts.Larc*1e9);
    else
        fprintf('Driven source at (%u,%u)\n\n', opts.arcNode(1), opts.arcNode(2));
    end
end

% Panel assumed charged uniformly to V0, nothing moving yet.
V = repmat(opts.V0, n, 1);
iB = zeros(nB,1);  iG = zeros(nG,1);  iC = zeros(n,1);
peakI = zeros(nB,1);  peakP = zeros(nB,1);  energyB = zeros(nB,1);
srcE  = 0;
tAll = [];  vAll = [];  iAll = [];
t = 0;
tic;

for s = 1:size(opts.stages,1)
    h = opts.stages(s,1);  tEnd = opts.stages(s,2);
    if t >= tEnd, continue; end

    gB = h ./ (2*bL  + h*bR );      % R+L series companion conductance
    gG = h ./ (2*gLv + h*gRv);
    gC = 2*Cn / h;                  % capacitor companion
    aB = h ./ (2*bL );
    aG = h ./ (2*gLv);

    offd = sparse([ba; bb], [bb; ba], [-gB; -gB], n, n);
    dg   = accumarray([ba; bb], [gB; gB], [n 1]);
    dg   = dg + accumarray(ga, gG, [n 1], [], 0) + gC;
    dY   = decomposition(offd + spdiags(dg,0,n,n), 'chol');

    nStep = ceil((tEnd - t)/h);
    if opts.verbose
        fprintf('h = %-9.3g to %-9.3g  (%u steps)\n', h, tEnd, nStep);
    end
    tS = zeros(nStep,1);  vS = zeros(nStep,numel(pRows));  iS = zeros(nStep,1);

    for k = 1:nStep
        Vp  = V;
        dVp = Vp(ba) - Vp(bb);

        IhB = (iB.*(1 - aB.*bR ) + aB.*dVp      ) ./ (1 + aB.*bR );
        IhG = (iG.*(1 - aG.*gRv) + aG.*Vp(ga)   ) ./ (1 + aG.*gRv);
        IhC = -gC.*Vp - iC;

        rhs = -accumarray(ba, IhB, [n 1]) + accumarray(bb, IhB, [n 1]) ...
              -accumarray(ga, IhG, [n 1], [], 0) - IhC;
        if ~isempty(opts.iFun)
            rhs(arcRow) = rhs(arcRow) + opts.iFun(t + h);
        end

        V  = dY \ rhs;
        dV = V(ba) - V(bb);
        iB = gB.*dV    + IhB;
        iG = gG.*V(ga) + IhG;
        iC = gC.*V     + IhC;
        t  = t + h;

        a = abs(iB);
        peakI   = max(peakI, a);
        peakP   = max(peakP, a.^2 .* bR);
        energyB = energyB + a.^2 .* bR * h;
        if arcIdx == 0, srcE = srcE + opts.iFun(t)*V(arcRow)*h; end

        tS(k) = t;  vS(k,:) = V(pRows).';
        if arcIdx > 0, iS(k) = iG(arcIdx); else, iS(k) = opts.iFun(t); end
    end
    tAll = [tAll; tS];  vAll = [vAll; vS];  iAll = [iAll; iS];   %#ok<AGROW>
end
elapsed = toc;

% Worst branch power at each node, and energy split between its endpoints so
% the map sums to the total in the threads.
pwr = max(accumarray(ba, peakP, [n 1], @max, 0), ...
          accumarray(bb, peakP, [n 1], @max, 0));
eng = accumarray(ba, energyB/2, [n 1], [], 0) + ...
      accumarray(bb, energyB/2, [n 1], [], 0);

idx = find(net.gridRow > 0);
PeakPowerMap = nan(p.nW,p.nL);  PeakPowerMap(idx) = pwr(net.gridRow(idx));
EnergyMap    = nan(p.nW,p.nL);  EnergyMap(idx)    = eng(net.gridRow(idx));

out = struct('t',tAll, 'Vprobe',vAll, 'iArc',iAll, ...
             'probeNames',{opts.probes(:,1)}, ...
             'peakBranchI',peakI, 'peakBranchP',peakP, 'energyBranch',energyB, ...
             'PeakPowerMap',PeakPowerMap, 'EnergyMap',EnergyMap, ...
             'straps',net.straps, 'p',p, 'opts',opts, 'elapsed',elapsed);
out.peakArcI   = max(abs(iAll));
out.chargeArc  = trapz(tAll, iAll);
out.driven     = (arcIdx == 0);
out.energyInit = 0.5 * p.panelCap * opts.V0^2;
out.srcEnergy  = srcE;

if opts.verbose
    fprintf('\n%u steps in %.2f s.\n', numel(tAll), elapsed);
    fprintf('  peak source current   %.4g A\n', out.peakArcI);
    fprintf('  charge delivered      %.4g C\n', out.chargeArc);
    fprintf('  worst branch current  %.4g A\n', max(peakI));
    fprintf('  worst branch power    %.4g W  (for ~ns)\n', max(peakP));
    fprintf('  worst branch energy   %.4g mJ\n', max(energyB)*1e3);
    if out.driven, Etot = srcE;  lbl = 'from the gun';
    else,          Etot = out.energyInit;  lbl = 'stored at t=0';
    end
    fprintf('  energy %-14s %.4g mJ\n', lbl, Etot*1e3);
    if Etot > 0
        fprintf('  into threads          %.4g mJ (%.1f%%)\n', ...
                sum(energyB)*1e3, 100*sum(energyB)/Etot);
        fprintf('  remainder             %.4g mJ (%.1f%%)\n', ...
                (Etot-sum(energyB))*1e3, 100*(Etot-sum(energyB))/Etot);
    end
end
end

% -----------------------------------------------------------------------
function f = iec_waveform(kV)
% IEC 61000-4-2 contact discharge current, as two Heidler functions.
% The standard specifies only peak, risetime, and the currents at 30 and
% 60 ns, so any analytic form is a fit.  Calibrated so 8 kV gives 30 A.
s  = kV/8;
n  = 1.8;
I1 = 30.0*s;  t1 = 1.1e-9;  t2 = 2.0e-9;      % fast front
I2 = 16.0*s;  t3 = 12e-9;   t4 = 37e-9;       % second hump
k1 = exp(-(t1/t2)*(n*t2/t1)^(1/n));
k2 = exp(-(t3/t4)*(n*t4/t3)^(1/n));
hd = @(t,I,ta,tb,k) (I/k) .* ((t./ta).^n ./ (1+(t./ta).^n)) .* exp(-t./tb);
f  = @(t) (t>0) .* (hd(max(t,0),I1,t1,t2,k1) + hd(max(t,0),I2,t3,t4,k2));
end
