function esd_plot(A, p, info)
% Draw one sheet map in millimetres, clamp contacts marked, NaN left blank.
step = p.gap + 1;
x = (0:p.nW-1)/step * p.threadSep;
y = (0:p.nL-1)/step * p.threadSep;

h = imagesc(x, y, A');
set(h, 'AlphaData', ~isnan(A'));
set(gca, 'YDir', 'normal', 'Color', [0.92 0.92 0.92], 'Toolbar', []);
axis image; xlabel('W (mm)'); ylabel('L (mm)');

hold on;
for s = info.straps
    yl = y(1);  if s.lNode > 1, yl = y(end); end
    plot(s.contactMM, repmat(yl, size(s.contactMM)), 'ws', ...
         'MarkerFaceColor', 'k', 'MarkerSize', 5);
end
hold off;
end
